package io.agileintelligence.fsbasicss1backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Fsbasicss1BackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
