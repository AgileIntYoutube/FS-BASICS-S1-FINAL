package io.agileintelligence.fsbasicss1backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Fsbasicss1BackendApplication {

	public static void main(String[] args) {
		SpringApplication.run(Fsbasicss1BackendApplication.class, args);
	}

}
